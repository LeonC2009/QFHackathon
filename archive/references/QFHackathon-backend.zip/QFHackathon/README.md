# QFHackathon: Carbon Pair Lab (backend)

Backend for **Carbon Pair Lab**, an illustrative Borsuk-Ulam-inspired energy
futures and carbon-risk hedge model. It sizes a pair of opposite futures legs
against a modeled carbon-cost shock and reports the resulting P&L and residual
exposure. All scenarios are synthetic.

Zero runtime dependencies: just Node.js (>= 22) and TypeScript tooling for dev.

## Quick start

```bash
npm install
npm test          # model + API tests
npm run dev       # http://localhost:3000 with auto-reload
# or
npm run build && npm start
```

Copy `.env.example` to `.env` if you want to change `PORT` / `CORS_ORIGIN`
(they are read from the environment).

## API

| Method | Path            | Description                                   |
| ------ | --------------- | --------------------------------------------- |
| GET    | `/api/health`   | Liveness check                                |
| GET    | `/api/defaults` | Default inputs and allowed min/max per field  |
| POST   | `/api/model`    | Run the model. JSON body, all fields optional |

### `POST /api/model`

```bash
curl -X POST http://localhost:3000/api/model \
  -H "Content-Type: application/json" \
  -d "{\"hedgeCoveragePct\": 65, \"carbonPriceShockPct\": 15}"
```

Input fields (omitted fields use the defaults):

| Field                    | Default | Meaning                              |
| ------------------------ | ------- | ------------------------------------ |
| `financedEmissionsTco2e` | 120000  | Annual financed emissions (tCO2e)    |
| `carbonPriceEurPerTonne` | 95      | Proxy carbon price (EUR/t)           |
| `carbonPriceShockPct`    | 15      | Carbon price shock (%)               |
| `hedgeCoveragePct`       | 65      | Share of the shock to hedge (%)      |
| `basisMovePct`           | 4.5     | Futures basis move (%)               |
| `futuresPriceEurPerMwh`  | 85      | Futures price (EUR/MWh)              |
| `contractSizeMwh`        | 1000    | Contract size (MWh)                  |

Returns `{ inputs, result }`. `result` includes `annualCarbonCostEur`,
`carbonCostShockEur`, `targetHedgeEur`, `pairedContracts`, `longNotionalEur`,
`shortNotionalEur`, `modeledPnlEur`, `residualShockExposureEur`,
`longSignature` / `shortSignature` and `signatureMatchError`.

Invalid input returns `422` with a `details` array; malformed JSON returns `400`.

## Use as a library

```ts
import { calculateCarbonPairModel, DEFAULT_INPUTS } from "./src/index.js";

const result = calculateCarbonPairModel(DEFAULT_INPUTS);
```

## Layout

```
src/carbon-pair-model.ts   core model (pure function, no I/O)
src/validate.ts            defaults, limits, request validation
src/app.ts                 HTTP routes (node:http)
src/server.ts              entrypoint
test/                      node:test suites
```

The model in `src/carbon-pair-model.ts` is taken unchanged from the original
Carbon Pair Lab app (`app/lib/carbon-pair-model.ts`).
