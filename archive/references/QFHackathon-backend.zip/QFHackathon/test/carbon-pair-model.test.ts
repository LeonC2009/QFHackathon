import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { calculateCarbonPairModel } from "../src/carbon-pair-model.js";
import { DEFAULT_INPUTS } from "../src/validate.js";

describe("calculateCarbonPairModel", () => {
  it("finds antipodal points with matching mapped risk signatures", () => {
    const r = calculateCarbonPairModel(DEFAULT_INPUTS);
    assert.ok(r.signatureMatchError < 1e-12);
    assert.ok(Math.abs(r.longSignature[0] - r.shortSignature[0]) < 1e-12);
    assert.ok(Math.abs(r.longSignature[1] - r.shortSignature[1]) < 1e-12);
  });

  it("sizes opposite futures legs from the modeled carbon-cost shock", () => {
    const r = calculateCarbonPairModel(DEFAULT_INPUTS);
    assert.equal(r.annualCarbonCostEur, 11_400_000);
    assert.equal(r.carbonCostShockEur, 1_710_000);
    assert.equal(r.pairedContracts, 291);
    assert.ok(Math.abs(r.longMoveEurPerMwh - 1.9125) < 1e-12);
    assert.ok(Math.abs(r.shortMoveEurPerMwh + 1.9125) < 1e-12);
    assert.equal(r.modeledPnlEur, 1_113_075);
    assert.equal(r.residualShockExposureEur, 596_925);
    assert.equal(r.financedEmissionsTco2e, DEFAULT_INPUTS.financedEmissionsTco2e);
  });

  it("returns no futures position when coverage or basis movement is zero", () => {
    const noCoverage = calculateCarbonPairModel({ ...DEFAULT_INPUTS, hedgeCoveragePct: 0 });
    const noBasis = calculateCarbonPairModel({ ...DEFAULT_INPUTS, basisMovePct: 0 });
    assert.equal(noCoverage.pairedContracts, 0);
    assert.equal(noCoverage.modeledPnlEur, 0);
    assert.equal(noCoverage.residualShockExposureEur, 1_710_000);
    assert.equal(noBasis.pairedContracts, 0);
    assert.equal(noBasis.modeledPnlEur, 0);
  });

  it("keeps outputs deterministic and finite for an empty portfolio", () => {
    const inputs = { ...DEFAULT_INPUTS, financedEmissionsTco2e: 0, carbonPriceEurPerTonne: 0 };
    const r = calculateCarbonPairModel(inputs);
    assert.deepEqual(r, calculateCarbonPairModel(inputs));
    assert.equal(r.pairedContracts, 0);
    assert.equal(r.residualShockExposureEur, 0);
  });
});
