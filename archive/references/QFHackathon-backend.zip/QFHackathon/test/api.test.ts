import assert from "node:assert/strict";
import type { AddressInfo } from "node:net";
import { after, before, describe, it } from "node:test";
import type { Server } from "node:http";

import { createApp } from "../src/app.js";

let server: Server;
let base: string;

before(async () => {
  server = createApp();
  await new Promise<void>((resolve) => server.listen(0, resolve));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => new Promise<void>((resolve) => server.close(() => resolve())));

const post = (body: string) =>
  fetch(`${base}/api/model`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
  });

describe("HTTP API", () => {
  it("GET /api/health", async () => {
    const res = await fetch(`${base}/api/health`);
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { status: "ok" });
  });

  it("GET /api/defaults returns defaults and limits", async () => {
    const body = (await (await fetch(`${base}/api/defaults`)).json()) as any;
    assert.equal(body.defaults.financedEmissionsTco2e, 120_000);
    assert.equal(body.limits.hedgeCoveragePct.max, 100);
  });

  it("POST /api/model with empty body uses defaults", async () => {
    const res = await post("");
    const body = (await res.json()) as any;
    assert.equal(res.status, 200);
    assert.equal(body.result.pairedContracts, 291);
    assert.equal(body.result.modeledPnlEur, 1_113_075);
  });

  it("POST /api/model applies overrides", async () => {
    const res = await post(JSON.stringify({ hedgeCoveragePct: 0 }));
    const body = (await res.json()) as any;
    assert.equal(res.status, 200);
    assert.equal(body.result.pairedContracts, 0);
    assert.equal(body.result.residualShockExposureEur, 1_710_000);
  });

  it("rejects bad types, out-of-range values and unknown fields", async () => {
    const res = await post(
      JSON.stringify({ hedgeCoveragePct: 150, basisMovePct: "x", nope: 1 }),
    );
    const body = (await res.json()) as any;
    assert.equal(res.status, 422);
    assert.equal(body.details.length, 3);
  });

  it("rejects malformed JSON with 400", async () => {
    assert.equal((await post("{oops")).status, 400);
  });

  it("returns 404 for unknown routes", async () => {
    assert.equal((await fetch(`${base}/nope`)).status, 404);
  });
});
