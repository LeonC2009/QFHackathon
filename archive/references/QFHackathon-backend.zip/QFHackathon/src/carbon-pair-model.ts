export type CarbonPairInputs = {
  financedEmissionsTco2e: number;
  carbonPriceEurPerTonne: number;
  carbonPriceShockPct: number;
  hedgeCoveragePct: number;
  basisMovePct: number;
  futuresPriceEurPerMwh: number;
  contractSizeMwh: number;
};

type Signature = [number, number];
type ScenarioPoint = [number, number, number];

const firstRiskAxis: ScenarioPoint = [0.8, 0.2, -0.3];
const secondRiskAxis: ScenarioPoint = [-0.25, 0.9, 0.15];

function normalize(point: ScenarioPoint): ScenarioPoint {
  const magnitude = Math.hypot(...point);
  return point.map((coordinate) => coordinate / magnitude) as ScenarioPoint;
}

function crossProduct(a: ScenarioPoint, b: ScenarioPoint): ScenarioPoint {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function mapRiskSignature([x, y, z]: ScenarioPoint): Signature {
  return [
    0.8 * x + 0.2 * y - 0.3 * z + 0.12 * x * z,
    -0.25 * x + 0.9 * y + 0.15 * z + 0.06 * y * z,
  ];
}

export function calculateCarbonPairModel(inputs: CarbonPairInputs) {
  const annualCarbonCostEur =
    inputs.financedEmissionsTco2e * inputs.carbonPriceEurPerTonne;
  const carbonCostShockEur =
    annualCarbonCostEur * (inputs.carbonPriceShockPct / 100);
  const targetHedgeEur = carbonCostShockEur * (inputs.hedgeCoveragePct / 100);
  const basisMoveEurPerMwh =
    inputs.futuresPriceEurPerMwh * (inputs.basisMovePct / 100);
  const spreadValuePerContractEur =
    basisMoveEurPerMwh * inputs.contractSizeMwh;
  const pairedContracts =
    targetHedgeEur > 0 && spreadValuePerContractEur > 0
      ? Math.round(targetHedgeEur / spreadValuePerContractEur)
      : 0;
  const modeledPnlEur =
    Math.round(pairedContracts * spreadValuePerContractEur * 100) / 100;
  const matchedScenarioAxis = normalize(
    crossProduct(firstRiskAxis, secondRiskAxis),
  );
  const oppositeScenarioAxis = matchedScenarioAxis.map(
    (coordinate) => -coordinate,
  ) as ScenarioPoint;
  const longSignature = mapRiskSignature(matchedScenarioAxis);
  const shortSignature = mapRiskSignature(oppositeScenarioAxis);

  return {
    annualCarbonCostEur,
    carbonCostShockEur,
    targetHedgeEur,
    basisMoveEurPerMwh,
    longMoveEurPerMwh: basisMoveEurPerMwh / 2,
    shortMoveEurPerMwh: -basisMoveEurPerMwh / 2,
    pairedContracts,
    longNotionalEur:
      pairedContracts * inputs.futuresPriceEurPerMwh * inputs.contractSizeMwh,
    shortNotionalEur:
      pairedContracts * inputs.futuresPriceEurPerMwh * inputs.contractSizeMwh,
    modeledPnlEur,
    residualShockExposureEur: carbonCostShockEur - modeledPnlEur,
    financedEmissionsTco2e: inputs.financedEmissionsTco2e,
    longSignature,
    shortSignature,
    signatureMatchError: Math.hypot(
      longSignature[0] - shortSignature[0],
      longSignature[1] - shortSignature[1],
    ),
  };
}
