import { createApp } from "./app.js";

const port = Number(process.env.PORT ?? 3000);
const app = createApp({ corsOrigin: process.env.CORS_ORIGIN ?? "*" });

app.listen(port, () => {
  console.log(`Carbon Pair Lab API listening on http://localhost:${port}`);
});
