import {
  createServer,
  type IncomingMessage,
  type Server,
  type ServerResponse,
} from "node:http";

import { calculateCarbonPairModel } from "./carbon-pair-model.js";
import { DEFAULT_INPUTS, INPUT_LIMITS, parseInputs } from "./validate.js";

const MAX_BODY_BYTES = 16 * 1024;

class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

function corsHeaders(origin: string) {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

function send(res: ServerResponse, status: number, payload: unknown, cors: string) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    ...corsHeaders(cors),
  });
  res.end(JSON.stringify(payload));
}

async function readJson(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > MAX_BODY_BYTES) throw new HttpError(413, "Body too large.");
    chunks.push(chunk as Buffer);
  }
  const text = Buffer.concat(chunks).toString("utf8");
  if (!text.trim()) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new HttpError(400, "Body is not valid JSON.");
  }
}

export function createApp(options: { corsOrigin?: string } = {}): Server {
  const cors = options.corsOrigin ?? "*";

  return createServer(async (req, res) => {
    try {
      const { pathname } = new URL(req.url ?? "/", "http://localhost");

      if (req.method === "OPTIONS") {
        res.writeHead(204, corsHeaders(cors));
        return res.end();
      }

      if (req.method === "GET" && pathname === "/api/health") {
        return send(res, 200, { status: "ok" }, cors);
      }

      if (req.method === "GET" && pathname === "/api/defaults") {
        return send(res, 200, { defaults: DEFAULT_INPUTS, limits: INPUT_LIMITS }, cors);
      }

      if (req.method === "POST" && pathname === "/api/model") {
        const parsed = parseInputs(await readJson(req));
        if (!parsed.ok) {
          return send(res, 422, { error: "Invalid input.", details: parsed.errors }, cors);
        }
        return send(
          res,
          200,
          { inputs: parsed.inputs, result: calculateCarbonPairModel(parsed.inputs) },
          cors,
        );
      }

      send(res, 404, { error: "Not found." }, cors);
    } catch (err) {
      if (err instanceof HttpError) {
        return send(res, err.status, { error: err.message }, cors);
      }
      console.error(err);
      send(res, 500, { error: "Internal server error." }, cors);
    }
  });
}
