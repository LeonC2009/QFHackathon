import type { CarbonPairInputs } from "./carbon-pair-model.js";

/** Default scenario (same as the original UI starting sliders). */
export const DEFAULT_INPUTS: CarbonPairInputs = {
  financedEmissionsTco2e: 120_000,
  carbonPriceEurPerTonne: 95,
  carbonPriceShockPct: 15,
  hedgeCoveragePct: 65,
  basisMovePct: 4.5,
  futuresPriceEurPerMwh: 85,
  contractSizeMwh: 1_000,
};

/** Allowed ranges. Wider than the original UI sliders so the API stays flexible. */
export const INPUT_LIMITS: Record<
  keyof CarbonPairInputs,
  { min: number; max: number }
> = {
  financedEmissionsTco2e: { min: 0, max: 1e9 },
  carbonPriceEurPerTonne: { min: 0, max: 10_000 },
  carbonPriceShockPct: { min: -100, max: 1_000 },
  hedgeCoveragePct: { min: 0, max: 100 },
  basisMovePct: { min: -100, max: 100 },
  futuresPriceEurPerMwh: { min: 0, max: 100_000 },
  contractSizeMwh: { min: 0, max: 1e9 },
};

export type ValidationResult =
  | { ok: true; inputs: CarbonPairInputs }
  | { ok: false; errors: string[] };

/**
 * Validates an untrusted request body. Missing fields fall back to
 * DEFAULT_INPUTS; present fields must be finite numbers inside INPUT_LIMITS.
 */
export function parseInputs(body: unknown): ValidationResult {
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return { ok: false, errors: ["Body must be a JSON object."] };
  }
  const raw = body as Record<string, unknown>;
  const errors: string[] = [];
  const inputs = { ...DEFAULT_INPUTS };

  for (const key of Object.keys(raw)) {
    if (!(key in INPUT_LIMITS)) errors.push(`Unknown field "${key}".`);
  }

  for (const key of Object.keys(INPUT_LIMITS) as (keyof CarbonPairInputs)[]) {
    if (!(key in raw)) continue;
    const value = raw[key];
    const { min, max } = INPUT_LIMITS[key];
    if (typeof value !== "number" || !Number.isFinite(value)) {
      errors.push(`"${key}" must be a finite number.`);
    } else if (value < min || value > max) {
      errors.push(`"${key}" must be between ${min} and ${max}.`);
    } else {
      inputs[key] = value;
    }
  }

  return errors.length ? { ok: false, errors } : { ok: true, inputs };
}
